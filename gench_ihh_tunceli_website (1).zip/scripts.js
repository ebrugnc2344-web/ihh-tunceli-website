// Simple script: newsletter form handler (no backend)
document.addEventListener('DOMContentLoaded', function(){
  var form = document.getElementById('newsletter');
  if(form){
    form.addEventListener('submit', function(e){
      e.preventDefault();
      alert('Teşekkürler! E-posta aboneliğiniz alındı (demo).');
      form.reset();
    });
  }
});
