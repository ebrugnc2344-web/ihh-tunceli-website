Bu klasör örnek görseller içindir. Gerçek görsellerinizi 'hero.jpg', 'edu.jpg', 'workshop.jpg', 'events.jpg', 'course1.jpg', etc. adlarıyla değiştirin.
